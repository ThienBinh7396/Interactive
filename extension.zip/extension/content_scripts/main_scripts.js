/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};

;// CONCATENATED MODULE: ./types/index.type.ts
var _DeviceTypeToValueMap;
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
var Contract = /*#__PURE__*/function (Contract) {
  Contract["C01"] = "c01";
  Contract["C02"] = "c02";
  Contract["C03"] = "c03";
  Contract["C06"] = "c06";
  Contract["C13"] = "c13";
  Contract["C90"] = "c90";
  return Contract;
}({});
var Plan = /*#__PURE__*/function (Plan) {
  Plan["SMP_S"] = "smpS";
  Plan["SMP_M"] = "smpM";
  Plan["SMP_L"] = "smpL";
  Plan["MBB"] = "mbb";
  Plan["KPSS"] = "kpss";
  return Plan;
}({});
var PaymentCount = /*#__PURE__*/function (PaymentCount) {
  PaymentCount["PC1"] = "pc1";
  PaymentCount["PC36"] = "pc36";
  PaymentCount["PC24"] = "pc24";
  return PaymentCount;
}({});
var Character = /*#__PURE__*/function (Character) {
  Character["CONTRACTOR"] = "contractor";
  Character["USER"] = "user";
  Character["PAYMENT_HOLDER"] = "paymentHolder";
  return Character;
}({});
var PageTitle = /*#__PURE__*/function (PageTitle) {
  PageTitle["PLAN"] = "plan";
  PageTitle["OPTION"] = "option";
  PageTitle["UPLOAD"] = "upload";
  PageTitle["INPUT"] = "input";
  PageTitle["ADDITION"] = "addition";
  PageTitle["PAYMENT"] = "payment";
  PageTitle["AGREEMENT"] = "agreement";
  PageTitle["CONFIRM"] = "confirm";
  return PageTitle;
}({});
var DeviceType = /*#__PURE__*/function (DeviceType) {
  DeviceType["Android"] = "android";
  DeviceType["Iphone"] = "iphone";
  DeviceType["Ipad"] = "ipad";
  return DeviceType;
}({});
var DeviceTypeToValueMapping = (_DeviceTypeToValueMap = {}, _defineProperty(_DeviceTypeToValueMap, DeviceType.Android, "android-smartphone"), _defineProperty(_DeviceTypeToValueMap, DeviceType.Iphone, "iPhone"), _defineProperty(_DeviceTypeToValueMap, DeviceType.Ipad, "iPad"), _DeviceTypeToValueMap);
;// CONCATENATED MODULE: ./constant/constant.ts
var SAMPLE_IMAGE_URL = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAMAAAC67D+PAAAAIGNIUk0AAHomAACAhAAA+gAAAIDoAAB1MAAA6mAAADqYAAAXcJy6UTwAAAA5UExURQCZ/wGa/wGZ/wCW/wCX/wCY/wWb/ySo/xOg/xGg/yWo/wac/wic/zWu/yGm/x6l/wmd/wKa/////9I5h8oAAAABYktHRBJ7vGwAAAAAB3RJTUUH5woCDR0ndZIblAAAADdJREFUCNdjYMAFGJmYGKFMZhZWZlYQg5WNnYOTixvEZuXh5ePnFWBlgihggShgYBBkYhLEaSYAL24A8BPvrKgAAAAldEVYdGRhdGU6Y3JlYXRlADIwMjMtMTAtMDJUMTM6Mjk6MzIrMDA6MDBKj9zuAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDIzLTEwLTAyVDEzOjI5OjMyKzAwOjAwO9JkUgAAACh0RVh0ZGF0ZTp0aW1lc3RhbXAAMjAyMy0xMC0wMlQxMzoyOTozOSswMDowMG7AEXcAAAAASUVORK5CYII=";
;// CONCATENATED MODULE: ./classes/action/Action.ts
function Action_typeof(o) { "@babel/helpers - typeof"; return Action_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, Action_typeof(o); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == Action_typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator["return"] && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(Action_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, "catch": function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, Action_toPropertyKey(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function Action_defineProperty(obj, key, value) { key = Action_toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function Action_toPropertyKey(arg) { var key = Action_toPrimitive(arg, "string"); return Action_typeof(key) === "symbol" ? key : String(key); }
function Action_toPrimitive(input, hint) { if (Action_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (Action_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }

var Action = /*#__PURE__*/function () {
  function Action() {
    _classCallCheck(this, Action);
    Action_defineProperty(this, "waitTimeout", undefined);
    Action_defineProperty(this, "endInterval", 0);
    Action_defineProperty(this, "waitInterval", undefined);
    this.loadSampleImage();
  }
  _createClass(Action, [{
    key: "clearInterval",
    value: function clearInterval() {
      window.clearInterval(this.waitInterval);
      this.waitInterval = undefined;
    }
  }, {
    key: "loadSampleImage",
    value: function () {
      var _loadSampleImage = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var _this = this;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              if (!(Action.sampleImageFileData.status !== "initial")) {
                _context.next = 2;
                break;
              }
              return _context.abrupt("return");
            case 2:
              return _context.abrupt("return", new Promise(function (resolve) {
                Action.sampleImageFileData.status = "loading";
                _this.getImageDataFromUrl(SAMPLE_IMAGE_URL, function (imageBlob) {
                  var fileName = "hasFilename.jpg";
                  var file = new File([imageBlob], fileName, {
                    type: "image/jpeg",
                    lastModified: new Date().getTime()
                  });
                  var container = new DataTransfer();
                  container.items.add(file);
                  Action.sampleImageFileData = {
                    value: container.files,
                    status: "done"
                  };
                  resolve(null);
                });
              }));
            case 3:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }));
      function loadSampleImage() {
        return _loadSampleImage.apply(this, arguments);
      }
      return loadSampleImage;
    }()
  }, {
    key: "getSampleImageFile",
    value: function () {
      var _getSampleImageFile = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              if (Action.sampleImageFileData.value) {
                _context2.next = 3;
                break;
              }
              _context2.next = 3;
              return this.loadSampleImage();
            case 3:
              return _context2.abrupt("return", Action.sampleImageFileData.value);
            case 4:
            case "end":
              return _context2.stop();
          }
        }, _callee2, this);
      }));
      function getSampleImageFile() {
        return _getSampleImageFile.apply(this, arguments);
      }
      return getSampleImageFile;
    }()
  }, {
    key: "getImageDataFromUrl",
    value: function getImageDataFromUrl(url, callback) {
      var xhr = new XMLHttpRequest();
      xhr.onload = function () {
        callback(xhr.response);
      };
      xhr.open("GET", url);
      xhr.responseType = "blob";
      xhr.send();
    }
  }, {
    key: "isFileUpload",
    value: function isFileUpload(selector) {
      var _this$selector;
      return this.checkElementExist(selector) && ((_this$selector = this.selector(selector)) === null || _this$selector === void 0 ? void 0 : _this$selector.getAttribute("type")) === "file";
    }
  }, {
    key: "findElementByText",
    value: function findElementByText(text) {
      return document.evaluate("//span[contains(text(), '".concat(text, "')]"), document, null, XPathResult.ANY_TYPE, null).iterateNext();
    }
  }, {
    key: "selector",
    value: function selector(_selector) {
      return document.querySelector(_selector);
    }
  }, {
    key: "toInputElement",
    value: function toInputElement(selector) {
      var selectorNode = this.selector(selector);
      if (selectorNode instanceof HTMLInputElement) {
        return selectorNode;
      }
      return null;
    }
  }, {
    key: "selectorAll",
    value: function selectorAll(selector) {
      return Array.from(document.querySelectorAll(selector) || []);
    }
  }, {
    key: "checkElementExist",
    value: function checkElementExist(selector) {
      return !!document.querySelector(selector);
    }
  }, {
    key: "clickTo",
    value: function clickTo(selector) {
      if (selector instanceof HTMLElement) {
        selector.scrollIntoView();
        selector.click();
        return;
      }
      var nodeElement = this.selector(selector);
      if (!nodeElement) {
        console.error("The element with the ".concat(selector, " selector does not exist."));
        return;
      }
      nodeElement.scrollIntoView();
      nodeElement.click();
    }
  }, {
    key: "select",
    value: function () {
      var _select = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3(selector, value) {
        var config,
          selectorNode,
          _args3 = arguments;
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
              config = _args3.length > 2 && _args3[2] !== undefined ? _args3[2] : {
                isDispatchChangeEvent: true,
                timeout: 0.2
              };
              selectorNode = this.selector(selector);
              if (selectorNode) {
                _context3.next = 5;
                break;
              }
              console.error("The element with the ".concat(selector, " selector does not exist."));
              return _context3.abrupt("return");
            case 5:
              if (!(selectorNode instanceof HTMLSelectElement)) {
                _context3.next = 12;
                break;
              }
              selectorNode.scrollIntoView();
              selectorNode.value = value;
              if (!config.isDispatchChangeEvent) {
                _context3.next = 12;
                break;
              }
              _context3.next = 11;
              return this.waitTime(config.timeout || 0.2);
            case 11:
              selectorNode.dispatchEvent(new Event("change"));
            case 12:
            case "end":
              return _context3.stop();
          }
        }, _callee3, this);
      }));
      function select(_x, _x2) {
        return _select.apply(this, arguments);
      }
      return select;
    }()
  }, {
    key: "selectFirstElement",
    value: function () {
      var _selectFirstElement = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee4(selector, value) {
        var selectorNode, isOptionAvailable, _selectorNode$querySe;
        return _regeneratorRuntime().wrap(function _callee4$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              selectorNode = this.selector(selector);
              if (selectorNode) {
                _context4.next = 4;
                break;
              }
              console.error("The element with the ".concat(selector, " selector does not exist."));
              return _context4.abrupt("return");
            case 4:
              _context4.next = 6;
              return this.waitFor(function () {
                var optionNode = selectorNode.querySelectorAll("option");
                return !!optionNode && optionNode.length >= 2;
              }, {
                interval: 300
              });
            case 6:
              isOptionAvailable = _context4.sent;
              if (isOptionAvailable) {
                _context4.next = 10;
                break;
              }
              console.error("The element with the ".concat(selector, " selector doesn' have any options!"));
              return _context4.abrupt("return");
            case 10:
              if (!(selectorNode instanceof HTMLSelectElement)) {
                _context4.next = 16;
                break;
              }
              selectorNode.value = value || ((_selectorNode$querySe = selectorNode.querySelector("option:nth-child(2)")) === null || _selectorNode$querySe === void 0 ? void 0 : _selectorNode$querySe.getAttribute("value")) || "";
              selectorNode.scrollIntoView();
              _context4.next = 15;
              return this.waitTime(0.2);
            case 15:
              selectorNode.dispatchEvent(new Event("change"));
            case 16:
            case "end":
              return _context4.stop();
          }
        }, _callee4, this);
      }));
      function selectFirstElement(_x3, _x4) {
        return _selectFirstElement.apply(this, arguments);
      }
      return selectFirstElement;
    }()
  }, {
    key: "fillField",
    value: function () {
      var _fillField = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee5(selector, value) {
        var isClearBeforeFill,
          selectorNode,
          _args5 = arguments;
        return _regeneratorRuntime().wrap(function _callee5$(_context5) {
          while (1) switch (_context5.prev = _context5.next) {
            case 0:
              isClearBeforeFill = _args5.length > 2 && _args5[2] !== undefined ? _args5[2] : false;
              selectorNode = this.selector(selector);
              if (selectorNode) {
                _context5.next = 5;
                break;
              }
              console.error("The element with the ".concat(selector, " selector does not exist."));
              return _context5.abrupt("return");
            case 5:
              if (!(selectorNode instanceof HTMLTextAreaElement || selectorNode instanceof HTMLInputElement)) {
                _context5.next = 18;
                break;
              }
              if (!isClearBeforeFill) {
                _context5.next = 13;
                break;
              }
              selectorNode.value = "";
              _context5.next = 10;
              return this.waitTime(0.05);
            case 10:
              selectorNode.dispatchEvent(new Event("input"));
              _context5.next = 13;
              return this.waitTime(0.05);
            case 13:
              selectorNode.value = value;
              selectorNode.scrollIntoView();
              _context5.next = 17;
              return this.waitTime(0.2);
            case 17:
              selectorNode.dispatchEvent(new Event("input"));
            case 18:
            case "end":
              return _context5.stop();
          }
        }, _callee5, this);
      }));
      function fillField(_x5, _x6) {
        return _fillField.apply(this, arguments);
      }
      return fillField;
    }()
  }, {
    key: "uploadFile",
    value: function () {
      var _uploadFile = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee6(selector) {
        var uploadImageNodeString, uploadImageNode, okButtonSelector, isOkButtonClickable;
        return _regeneratorRuntime().wrap(function _callee6$(_context6) {
          while (1) switch (_context6.prev = _context6.next) {
            case 0:
              if (this.checkElementExist(selector)) {
                _context6.next = 3;
                break;
              }
              console.error("The element with the ".concat(selector, " selector does not exist."));
              return _context6.abrupt("return");
            case 3:
              this.clickTo("".concat(selector, " label"));
              uploadImageNodeString = "".concat(selector, "-reader input[name='image-select-input']");
              _context6.next = 7;
              return this.waitForAvailable(uploadImageNodeString);
            case 7:
              uploadImageNode = this.selector(uploadImageNodeString);
              if (this.isFileUpload(uploadImageNodeString)) {
                _context6.next = 11;
                break;
              }
              console.error("Cannot find upload file element with the ".concat(selector, " selector."));
              return _context6.abrupt("return");
            case 11:
              if (uploadImageNode instanceof HTMLInputElement) {
                _context6.next = 13;
                break;
              }
              return _context6.abrupt("return");
            case 13:
              _context6.next = 15;
              return Action.sampleImageFileData.value;
            case 15:
              uploadImageNode.files = _context6.sent;
              uploadImageNode.dispatchEvent(new Event("change"));
              okButtonSelector = "".concat(selector, "-ok");
              _context6.next = 20;
              return this.waitForClickable(okButtonSelector);
            case 20:
              isOkButtonClickable = _context6.sent;
              if (isOkButtonClickable) {
                _context6.next = 24;
                break;
              }
              console.error("Cannot find upload file element with the ".concat(selector, " selector."));
              return _context6.abrupt("return");
            case 24:
              this.clickTo(okButtonSelector);
            case 25:
            case "end":
              return _context6.stop();
          }
        }, _callee6, this);
      }));
      function uploadFile(_x7) {
        return _uploadFile.apply(this, arguments);
      }
      return uploadFile;
    }()
  }, {
    key: "waitTime",
    value: function waitTime(timeout) {
      var _this2 = this;
      return new Promise(function (resolve) {
        if (_this2.waitTimeout) {
          window.clearTimeout(_this2.waitTimeout);
        }
        _this2.waitTimeout = window.setTimeout(function () {
          resolve(null);
        }, timeout * 1000);
      });
    }
  }, {
    key: "waitFor",
    value: function waitFor(condition, options) {
      var _this3 = this;
      var timeout = (options === null || options === void 0 ? void 0 : options.timeout) || 30; // s
      var interval = (options === null || options === void 0 ? void 0 : options.interval) || 200; // ms

      return new Promise(function (resolve) {
        if (_this3.waitInterval) {
          _this3.clearInterval();
        }
        _this3.endInterval = new Date().getTime() + timeout * 1000;
        _this3.waitInterval = window.setInterval(function () {
          if (new Date().getTime() >= _this3.endInterval) {
            _this3.clearInterval();
            console.log("Fail in Interactive.waitFor");
            resolve(false);
          }
          if (condition()) {
            console.log("Success in Interactive.waitFor");
            _this3.clearInterval();
            resolve(true);
          }
        }, interval);
      });
    }
  }, {
    key: "waitForAvailable",
    value: function () {
      var _waitForAvailable = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee7(selector, options) {
        var _this4 = this;
        var timeout;
        return _regeneratorRuntime().wrap(function _callee7$(_context7) {
          while (1) switch (_context7.prev = _context7.next) {
            case 0:
              timeout = (options === null || options === void 0 ? void 0 : options.timeout) || 10000;
              _context7.next = 3;
              return this.waitFor(function () {
                var elementNode = _this4.selector(selector);
                var isElementClickable = (elementNode === null || elementNode === void 0 ? void 0 : elementNode.getAttribute("disabled")) !== "disabled";
                return !!elementNode && isElementClickable;
              }, {
                timeout: timeout
              });
            case 3:
              return _context7.abrupt("return", _context7.sent);
            case 4:
            case "end":
              return _context7.stop();
          }
        }, _callee7, this);
      }));
      function waitForAvailable(_x8, _x9) {
        return _waitForAvailable.apply(this, arguments);
      }
      return waitForAvailable;
    }()
  }, {
    key: "waitForClickable",
    value: function () {
      var _waitForClickable = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee8(selector, options) {
        var _this5 = this;
        var timeout;
        return _regeneratorRuntime().wrap(function _callee8$(_context8) {
          while (1) switch (_context8.prev = _context8.next) {
            case 0:
              timeout = (options === null || options === void 0 ? void 0 : options.timeout) || 10000;
              _context8.next = 3;
              return this.waitFor(function () {
                var _elementNode$style;
                var elementNode = _this5.selector(selector);
                var isElementClickable = (elementNode === null || elementNode === void 0 || (_elementNode$style = elementNode.style) === null || _elementNode$style === void 0 ? void 0 : _elementNode$style.pointerEvents) !== "none" && (elementNode === null || elementNode === void 0 ? void 0 : elementNode.getAttribute("disabled")) !== "disabled";
                return !!elementNode && isElementClickable;
              }, {
                timeout: timeout
              });
            case 3:
              return _context8.abrupt("return", _context8.sent);
            case 4:
            case "end":
              return _context8.stop();
          }
        }, _callee8, this);
      }));
      function waitForClickable(_x10, _x11) {
        return _waitForClickable.apply(this, arguments);
      }
      return waitForClickable;
    }()
  }]);
  return Action;
}();
Action_defineProperty(Action, "sampleImageFileData", {
  value: null,
  status: "initial"
});
/* harmony default export */ const action_Action = (Action);
;// CONCATENATED MODULE: ./classes/pages/Common.ts
function Common_typeof(o) { "@babel/helpers - typeof"; return Common_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, Common_typeof(o); }
function Common_regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ Common_regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == Common_typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator["return"] && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(Common_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, "catch": function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function Common_asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function Common_asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { Common_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { Common_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function Common_classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function Common_defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, Common_toPropertyKey(descriptor.key), descriptor); } }
function Common_createClass(Constructor, protoProps, staticProps) { if (protoProps) Common_defineProperties(Constructor.prototype, protoProps); if (staticProps) Common_defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function Common_toPropertyKey(arg) { var key = Common_toPrimitive(arg, "string"); return Common_typeof(key) === "symbol" ? key : String(key); }
function Common_toPrimitive(input, hint) { if (Common_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (Common_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); Object.defineProperty(subClass, "prototype", { writable: false }); if (superClass) _setPrototypeOf(subClass, superClass); }
function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }
function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }
function _possibleConstructorReturn(self, call) { if (call && (Common_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return _assertThisInitialized(self); }
function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }


var Common = /*#__PURE__*/function (_Action) {
  _inherits(Common, _Action);
  var _super = _createSuper(Common);
  function Common() {
    Common_classCallCheck(this, Common);
    return _super.apply(this, arguments);
  }
  Common_createClass(Common, [{
    key: "toPrefixCharacter",
    value: function toPrefixCharacter(character) {
      return character === "contractor" ? character : "first-".concat(character);
    }
  }, {
    key: "uploadCharacterCertificateDocument",
    value: function () {
      var _uploadCharacterCertificateDocument = Common_asyncToGenerator( /*#__PURE__*/Common_regeneratorRuntime().mark(function _callee(character) {
        return Common_regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return this.uploadFile("#".concat(this.toPrefixCharacter(character), "-certificate-main-image1"));
            case 2:
            case "end":
              return _context.stop();
          }
        }, _callee, this);
      }));
      function uploadCharacterCertificateDocument(_x) {
        return _uploadCharacterCertificateDocument.apply(this, arguments);
      }
      return uploadCharacterCertificateDocument;
    }()
  }, {
    key: "fillCharacterName",
    value: function () {
      var _fillCharacterName = Common_asyncToGenerator( /*#__PURE__*/Common_regeneratorRuntime().mark(function _callee2(character, nameConfig) {
        var firstNameKanji, lastNameKanji, firstNameKana, lastNameKana, prefixCharacter;
        return Common_regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              firstNameKanji = (nameConfig === null || nameConfig === void 0 ? void 0 : nameConfig.firstNameKanji) || "契";
              lastNameKanji = (nameConfig === null || nameConfig === void 0 ? void 0 : nameConfig.lastNameKanji) || "カナカナ";
              firstNameKana = (nameConfig === null || nameConfig === void 0 ? void 0 : nameConfig.firstNameKana) || "カナ";
              lastNameKana = (nameConfig === null || nameConfig === void 0 ? void 0 : nameConfig.lastNameKana) || "カナ";
              prefixCharacter = character === "contractor" ? character : "first-".concat(character);
              _context2.next = 7;
              return this.fillField("#".concat(prefixCharacter, "-last-name"), firstNameKanji);
            case 7:
              _context2.next = 9;
              return this.fillField("#".concat(prefixCharacter, "-first-name"), lastNameKanji);
            case 9:
              _context2.next = 11;
              return this.fillField("#".concat(prefixCharacter, "-last-name-kana"), firstNameKana);
            case 11:
              _context2.next = 13;
              return this.fillField("#".concat(prefixCharacter, "-first-name-kana"), lastNameKana);
            case 13:
            case "end":
              return _context2.stop();
          }
        }, _callee2, this);
      }));
      function fillCharacterName(_x2, _x3) {
        return _fillCharacterName.apply(this, arguments);
      }
      return fillCharacterName;
    }()
  }, {
    key: "selectCharacterGender",
    value: function selectCharacterGender(character) {
      var isMale = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
      var prefixCharacter = this.toPrefixCharacter(character);
      var genderSelector = isMale ? "#".concat(prefixCharacter, "-gender-radio-01-label") : "".concat(prefixCharacter, "-gender-radio-02-label");
      this.clickTo(genderSelector);
    }
  }, {
    key: "fillCharacterBirthDay",
    value: function () {
      var _fillCharacterBirthDay = Common_asyncToGenerator( /*#__PURE__*/Common_regeneratorRuntime().mark(function _callee3(character, options) {
        var birthday, isAdult, characterBirthday;
        return Common_regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
              birthday = options === null || options === void 0 ? void 0 : options.birthday;
              isAdult = (options === null || options === void 0 ? void 0 : options.isAdult) === undefined ? true : options === null || options === void 0 ? void 0 : options.isAdult;
              if (!birthday) {
                _context3.next = 6;
                break;
              }
              _context3.next = 5;
              return this.fillField("#".concat(this.toPrefixCharacter(character), "-birthday"), birthday);
            case 5:
              return _context3.abrupt("return");
            case 6:
              characterBirthday = isAdult ? "19890131" : "20150131";
              _context3.next = 9;
              return this.fillField("#".concat(this.toPrefixCharacter(character), "-birthday"), characterBirthday);
            case 9:
            case "end":
              return _context3.stop();
          }
        }, _callee3, this);
      }));
      function fillCharacterBirthDay(_x4, _x5) {
        return _fillCharacterBirthDay.apply(this, arguments);
      }
      return fillCharacterBirthDay;
    }()
  }, {
    key: "waitForPage",
    value: function () {
      var _waitForPage = Common_asyncToGenerator( /*#__PURE__*/Common_regeneratorRuntime().mark(function _callee4(page) {
        var _this = this;
        var pageTitle;
        return Common_regeneratorRuntime().wrap(function _callee4$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              pageTitle = "";
              _context4.t0 = page;
              _context4.next = _context4.t0 === PageTitle.OPTION ? 4 : _context4.t0 === PageTitle.UPLOAD ? 6 : _context4.t0 === PageTitle.INPUT ? 8 : _context4.t0 === PageTitle.PAYMENT ? 10 : 12;
              break;
            case 4:
              pageTitle = "オプション選択";
              return _context4.abrupt("break", 12);
            case 6:
              pageTitle = "本人確認";
              return _context4.abrupt("break", 12);
            case 8:
              pageTitle = "お客さま情報入力";
              return _context4.abrupt("break", 12);
            case 10:
              pageTitle = "お支払い情報";
              return _context4.abrupt("break", 12);
            case 12:
              _context4.next = 14;
              return this.waitFor(function () {
                var allH1Nodes = _this.selectorAll("h1");
                return allH1Nodes.some(function (node) {
                  var _node$textContent;
                  return (_node$textContent = node.textContent) === null || _node$textContent === void 0 ? void 0 : _node$textContent.includes(pageTitle);
                });
              });
            case 14:
              _context4.next = 16;
              return this.waitTime(1);
            case 16:
            case "end":
              return _context4.stop();
          }
        }, _callee4, this);
      }));
      function waitForPage(_x6) {
        return _waitForPage.apply(this, arguments);
      }
      return waitForPage;
    }()
  }, {
    key: "nextPage",
    value: function () {
      var _nextPage = Common_asyncToGenerator( /*#__PURE__*/Common_regeneratorRuntime().mark(function _callee5(page) {
        var nextButtonSelector;
        return Common_regeneratorRuntime().wrap(function _callee5$(_context5) {
          while (1) switch (_context5.prev = _context5.next) {
            case 0:
              nextButtonSelector = this.getNextButtonSelector(page);
              _context5.next = 3;
              return this.waitForClickable(nextButtonSelector);
            case 3:
              this.clickTo(nextButtonSelector);
            case 4:
            case "end":
              return _context5.stop();
          }
        }, _callee5, this);
      }));
      function nextPage(_x7) {
        return _nextPage.apply(this, arguments);
      }
      return nextPage;
    }()
  }, {
    key: "scrollToNextPageButton",
    value: function () {
      var _scrollToNextPageButton = Common_asyncToGenerator( /*#__PURE__*/Common_regeneratorRuntime().mark(function _callee6(page) {
        var _this$selector;
        return Common_regeneratorRuntime().wrap(function _callee6$(_context6) {
          while (1) switch (_context6.prev = _context6.next) {
            case 0:
              (_this$selector = this.selector(this.getNextButtonSelector(page))) === null || _this$selector === void 0 || _this$selector.scrollIntoView();
            case 1:
            case "end":
              return _context6.stop();
          }
        }, _callee6, this);
      }));
      function scrollToNextPageButton(_x8) {
        return _scrollToNextPageButton.apply(this, arguments);
      }
      return scrollToNextPageButton;
    }()
  }, {
    key: "getNextButtonSelector",
    value: function getNextButtonSelector(page) {
      var nextButtonSelector = "";
      switch (page) {
        case PageTitle.PLAN:
          nextButtonSelector = "#plan-next-button";
          break;
        case PageTitle.OPTION:
          nextButtonSelector = "#option-next-button";
          break;
        case PageTitle.UPLOAD:
          nextButtonSelector = "#upload-next-button";
          break;
        case PageTitle.INPUT:
          nextButtonSelector = "#input-next-button";
          break;
        case PageTitle.PAYMENT:
          nextButtonSelector = "#payment-next-button";
          break;
        case PageTitle.AGREEMENT:
          nextButtonSelector = "#agreements-next-button";
          break;
        case PageTitle.ADDITION:
          nextButtonSelector = "#upload-next-button";
          break;
      }
      return nextButtonSelector;
    }
  }]);
  return Common;
}(action_Action);
/* harmony default export */ const pages_Common = (Common);
;// CONCATENATED MODULE: ./classes/mocks/MockApi.ts
function MockApi_typeof(o) { "@babel/helpers - typeof"; return MockApi_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, MockApi_typeof(o); }
var _class;
function MockApi_classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function MockApi_defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, MockApi_toPropertyKey(descriptor.key), descriptor); } }
function MockApi_createClass(Constructor, protoProps, staticProps) { if (protoProps) MockApi_defineProperties(Constructor.prototype, protoProps); if (staticProps) MockApi_defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function MockApi_toPropertyKey(arg) { var key = MockApi_toPrimitive(arg, "string"); return MockApi_typeof(key) === "symbol" ? key : String(key); }
function MockApi_toPrimitive(input, hint) { if (MockApi_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (MockApi_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function _classStaticPrivateFieldSpecSet(receiver, classConstructor, descriptor, value) { _classCheckPrivateStaticAccess(receiver, classConstructor); _classCheckPrivateStaticFieldDescriptor(descriptor, "set"); _classApplyDescriptorSet(receiver, descriptor, value); return value; }
function _classApplyDescriptorSet(receiver, descriptor, value) { if (descriptor.set) { descriptor.set.call(receiver, value); } else { if (!descriptor.writable) { throw new TypeError("attempted to set read only private field"); } descriptor.value = value; } }
function _classStaticPrivateFieldSpecGet(receiver, classConstructor, descriptor) { _classCheckPrivateStaticAccess(receiver, classConstructor); _classCheckPrivateStaticFieldDescriptor(descriptor, "get"); return _classApplyDescriptorGet(receiver, descriptor); }
function _classCheckPrivateStaticFieldDescriptor(descriptor, action) { if (descriptor === undefined) { throw new TypeError("attempted to " + action + " private static field before its declaration"); } }
function _classApplyDescriptorGet(receiver, descriptor) { if (descriptor.get) { return descriptor.get.call(receiver); } return descriptor.value; }
function _classStaticPrivateMethodGet(receiver, classConstructor, method) { _classCheckPrivateStaticAccess(receiver, classConstructor); return method; }
function _classCheckPrivateStaticAccess(receiver, classConstructor) { if (receiver !== classConstructor) { throw new TypeError("Private static access of wrong provenance"); } }
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable prefer-rest-params */
var MockApi = /*#__PURE__*/function () {
  function MockApi() {
    MockApi_classCallCheck(this, MockApi);
  }
  MockApi_createClass(MockApi, null, [{
    key: "addMock",
    value: function addMock(mockConfig) {
      if (!_classStaticPrivateMethodGet(this, MockApi, _validateMock).call(this, mockConfig)) return;
      var foundMock = _classStaticPrivateMethodGet(this, MockApi, _findMock).call(this, mockConfig);
      if (foundMock) {
        foundMock.mockValue = mockConfig.mockValue;
      } else {
        _classStaticPrivateFieldSpecGet(this, MockApi, _mockConfig).push(mockConfig);
      }
    }
  }, {
    key: "resetMock",
    value: function resetMock() {
      _classStaticPrivateFieldSpecSet(this, MockApi, _mockConfig, []);
    }
  }]);
  return MockApi;
}();
_class = MockApi;
function _foundMockFromUrl(url) {
  console.log("this.#mockConfig: ", _classStaticPrivateFieldSpecGet(this, _class, _mockConfig));
  console.log("URL: ", url);
  return _classStaticPrivateFieldSpecGet(this, _class, _mockConfig).find(function (mock) {
    return mock.urlPatternString && new RegExp(mock.urlPatternString).test(url.toString()) || mock.url === url;
  });
}
function _findMock(mockConfig) {
  return _classStaticPrivateFieldSpecGet(this, _class, _mockConfig).find(function (mock) {
    return mock.url === mockConfig.url || mock.urlPatternString === mockConfig.urlPatternString;
  });
}
function _validateMock(mockConfig) {
  var isValid = mockConfig.url || mockConfig.urlPatternString;
  if (!isValid) {
    console.error("The mock config ".concat(JSON.stringify(mockConfig), " is invalid!!!"));
  }
  return isValid;
}
var _mockConfig = {
  writable: true,
  value: []
};
(function () {
  console.log("Run MockApi");
  var _open = window.XMLHttpRequest.prototype.open;
  window.XMLHttpRequest.prototype.open = function (method, url) {
    var _onreadystatechange = this.onreadystatechange;
    var self = this;
    self.onreadystatechange = function () {
      if (self.readyState === 4) {
        var foundMock = _classStaticPrivateMethodGet(_class, _class, _foundMockFromUrl).call(_class, url);
        if (foundMock) {
          try {
            // rewrite responseText
            Object.defineProperty(self, "responseText", {
              value: JSON.stringify(foundMock.mockValue.responseData)
            });
            Object.defineProperty(self, "status", {
              value: foundMock.mockValue.status
            });
          } catch (e) {
            console.log("Error occur when mock api with url: ".concat(URL), e);
          }
        }
      }
      // call original callback
      if (_onreadystatechange) _onreadystatechange.apply(self, arguments);
    };

    // detect any onreadystatechange changing
    Object.defineProperty(this, "onreadystatechange", {
      get: function get() {
        return _onreadystatechange;
      },
      set: function set(value) {
        _onreadystatechange = value;
      }
    });
    return _open.apply(self, arguments);
  };
})();
/* harmony default export */ const mocks_MockApi = (MockApi);
;// CONCATENATED MODULE: ./classes/pages/InputPage.ts
function InputPage_typeof(o) { "@babel/helpers - typeof"; return InputPage_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, InputPage_typeof(o); }
function InputPage_regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ InputPage_regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == InputPage_typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator["return"] && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(InputPage_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, "catch": function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function InputPage_asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function InputPage_asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { InputPage_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { InputPage_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function InputPage_classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function InputPage_defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, InputPage_toPropertyKey(descriptor.key), descriptor); } }
function InputPage_createClass(Constructor, protoProps, staticProps) { if (protoProps) InputPage_defineProperties(Constructor.prototype, protoProps); if (staticProps) InputPage_defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function InputPage_toPropertyKey(arg) { var key = InputPage_toPrimitive(arg, "string"); return InputPage_typeof(key) === "symbol" ? key : String(key); }
function InputPage_toPrimitive(input, hint) { if (InputPage_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (InputPage_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function InputPage_inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); Object.defineProperty(subClass, "prototype", { writable: false }); if (superClass) InputPage_setPrototypeOf(subClass, superClass); }
function InputPage_setPrototypeOf(o, p) { InputPage_setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return InputPage_setPrototypeOf(o, p); }
function InputPage_createSuper(Derived) { var hasNativeReflectConstruct = InputPage_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = InputPage_getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = InputPage_getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return InputPage_possibleConstructorReturn(this, result); }; }
function InputPage_possibleConstructorReturn(self, call) { if (call && (InputPage_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return InputPage_assertThisInitialized(self); }
function InputPage_assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }
function InputPage_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
function InputPage_getPrototypeOf(o) { InputPage_getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return InputPage_getPrototypeOf(o); }



var InputPage = /*#__PURE__*/function (_Common) {
  InputPage_inherits(InputPage, _Common);
  var _super = InputPage_createSuper(InputPage);
  function InputPage() {
    InputPage_classCallCheck(this, InputPage);
    return _super.apply(this, arguments);
  }
  InputPage_createClass(InputPage, [{
    key: "fillContractorPrimaryPhoneNumber",
    value: function () {
      var _fillContractorPrimaryPhoneNumber = InputPage_asyncToGenerator( /*#__PURE__*/InputPage_regeneratorRuntime().mark(function _callee() {
        var _this$selector;
        var phoneNumber,
          _args = arguments;
        return InputPage_regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              phoneNumber = _args.length > 0 && _args[0] !== undefined ? _args[0] : "09010231311";
              _context.next = 3;
              return this.fillField("#primary-phone-number", phoneNumber);
            case 3:
              _context.next = 5;
              return this.waitTime(0.05);
            case 5:
              (_this$selector = this.selector("#primary-phone-number")) === null || _this$selector === void 0 || _this$selector.dispatchEvent(new Event("blur"));
            case 6:
            case "end":
              return _context.stop();
          }
        }, _callee, this);
      }));
      function fillContractorPrimaryPhoneNumber() {
        return _fillContractorPrimaryPhoneNumber.apply(this, arguments);
      }
      return fillContractorPrimaryPhoneNumber;
    }()
  }, {
    key: "fillContractorZipCode",
    value: function () {
      var _fillContractorZipCode = InputPage_asyncToGenerator( /*#__PURE__*/InputPage_regeneratorRuntime().mark(function _callee2() {
        var _this = this;
        var zipCode,
          isZipCodeAvailable,
          addressSelectNode,
          _args2 = arguments;
        return InputPage_regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              zipCode = _args2.length > 0 && _args2[0] !== undefined ? _args2[0] : "1000000";
              _context2.next = 3;
              return this.fillField("#zip-code", zipCode, true);
            case 3:
              _context2.next = 5;
              return this.waitTime(2);
            case 5:
              _context2.next = 7;
              return this.waitFor(function () {
                return _this.selectorAll("#address option").length >= 2;
              });
            case 7:
              isZipCodeAvailable = _context2.sent;
              if (isZipCodeAvailable) {
                _context2.next = 11;
                break;
              }
              console.error("The ".concat(zipCode, " zipCode is unavailable."));
              return _context2.abrupt("return");
            case 11:
              addressSelectNode = this.selector("#address");
              addressSelectNode.value = this.selector("#address option:nth-child(2)").getAttribute("value") || "";
              addressSelectNode.dispatchEvent(new Event("change"));
              _context2.next = 16;
              return this.fillField("#incidental-address", "１０ー１　ビル");
            case 16:
            case "end":
              return _context2.stop();
          }
        }, _callee2, this);
      }));
      function fillContractorZipCode() {
        return _fillContractorZipCode.apply(this, arguments);
      }
      return fillContractorZipCode;
    }()
  }, {
    key: "fillContractorEmail",
    value: function () {
      var _fillContractorEmail = InputPage_asyncToGenerator( /*#__PURE__*/InputPage_regeneratorRuntime().mark(function _callee3() {
        var _this2 = this;
        var isInputOneTimePasswordAvailable;
        return InputPage_regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
              _context3.next = 2;
              return this.fillField("#email", "daichi.nomura@g.softbank.co.jp");
            case 2:
              mocks_MockApi.addMock({
                url: "https://general-bff-1.dev-sb-online.biz/api/v1/mail-confirmations/verify",
                mockValue: {
                  status: 200,
                  responseData: {
                    value: "ok"
                  }
                }
              });
              this.clickTo("#send-mail-button");
              _context3.next = 6;
              return this.waitFor(function () {
                var modalAuthNode = _this2.selector("#mail-auth-modal");
                return !!modalAuthNode && window.getComputedStyle(modalAuthNode).display !== "none";
              });
            case 6:
              console.log("Log: Show mail auth modal");
              _context3.next = 9;
              return this.waitForAvailable("#input-one-time-password");
            case 9:
              isInputOneTimePasswordAvailable = _context3.sent;
              if (isInputOneTimePasswordAvailable) {
                _context3.next = 13;
                break;
              }
              console.error("The OTP isn't available!");
              return _context3.abrupt("return");
            case 13:
              _context3.next = 15;
              return this.fillField("#input-one-time-password", "123");
            case 15:
              _context3.next = 17;
              return this.waitFor(function () {
                var modalAuthNode = _this2.selector("#mail-auth-modal");
                return !!modalAuthNode && window.getComputedStyle(modalAuthNode).display === "none";
              });
            case 17:
              this.clickTo("#email-send-agreement");
            case 18:
            case "end":
              return _context3.stop();
          }
        }, _callee3, this);
      }));
      function fillContractorEmail() {
        return _fillContractorEmail.apply(this, arguments);
      }
      return fillContractorEmail;
    }()
  }, {
    key: "fillUserFamily",
    value: function () {
      var _fillUserFamily = InputPage_asyncToGenerator( /*#__PURE__*/InputPage_regeneratorRuntime().mark(function _callee4() {
        var isUserAdult,
          _args4 = arguments;
        return InputPage_regeneratorRuntime().wrap(function _callee4$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              isUserAdult = _args4.length > 0 && _args4[0] !== undefined ? _args4[0] : true;
              this.clickTo("#first-user-identity-radio-02");
              _context4.next = 4;
              return this.waitTime(1);
            case 4:
              _context4.next = 6;
              return this.fillCharacterName(Character.USER);
            case 6:
              this.selectCharacterGender(Character.USER);
              _context4.next = 9;
              return this.fillCharacterBirthDay(Character.USER, {
                isAdult: isUserAdult
              });
            case 9:
              _context4.next = 11;
              return this.fillField("#first-user-network-pass-code", "4321");
            case 11:
            case "end":
              return _context4.stop();
          }
        }, _callee4, this);
      }));
      function fillUserFamily() {
        return _fillUserFamily.apply(this, arguments);
      }
      return fillUserFamily;
    }()
  }]);
  return InputPage;
}(pages_Common);
/* harmony default export */ const pages_InputPage = (InputPage);
;// CONCATENATED MODULE: ./classes/pages/OptionsPage.ts
function OptionsPage_typeof(o) { "@babel/helpers - typeof"; return OptionsPage_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, OptionsPage_typeof(o); }
function OptionsPage_classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function OptionsPage_defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, OptionsPage_toPropertyKey(descriptor.key), descriptor); } }
function OptionsPage_createClass(Constructor, protoProps, staticProps) { if (protoProps) OptionsPage_defineProperties(Constructor.prototype, protoProps); if (staticProps) OptionsPage_defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function OptionsPage_toPropertyKey(arg) { var key = OptionsPage_toPrimitive(arg, "string"); return OptionsPage_typeof(key) === "symbol" ? key : String(key); }
function OptionsPage_toPrimitive(input, hint) { if (OptionsPage_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (OptionsPage_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function OptionsPage_inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); Object.defineProperty(subClass, "prototype", { writable: false }); if (superClass) OptionsPage_setPrototypeOf(subClass, superClass); }
function OptionsPage_setPrototypeOf(o, p) { OptionsPage_setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return OptionsPage_setPrototypeOf(o, p); }
function OptionsPage_createSuper(Derived) { var hasNativeReflectConstruct = OptionsPage_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = OptionsPage_getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = OptionsPage_getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return OptionsPage_possibleConstructorReturn(this, result); }; }
function OptionsPage_possibleConstructorReturn(self, call) { if (call && (OptionsPage_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return OptionsPage_assertThisInitialized(self); }
function OptionsPage_assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }
function OptionsPage_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
function OptionsPage_getPrototypeOf(o) { OptionsPage_getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return OptionsPage_getPrototypeOf(o); }

var OptionsPage = /*#__PURE__*/function (_Common) {
  OptionsPage_inherits(OptionsPage, _Common);
  var _super = OptionsPage_createSuper(OptionsPage);
  function OptionsPage() {
    OptionsPage_classCallCheck(this, OptionsPage);
    return _super.apply(this, arguments);
  }
  OptionsPage_createClass(OptionsPage, [{
    key: "selectOption",
    value:
    // datazoryo, super_daretei_S, kosyou_pp_b, security_iphone, group_call, number_block, warikomi_call, wide_support
    function selectOption(optionId, isSelected) {
      var optionSelectorString = "#first-".concat(optionId);
      var optionSelectorNode = this.selector(optionSelectorString);
      if (!optionSelectorNode) {
        console.log("Option ".concat(optionId, " isn't exists."));
        return;
      }
      if (isSelected) {
        this.clickTo(optionSelectorString);
        return;
      }
      var parentNode = optionSelectorNode.closest("div");
      var noOptionNode = parentNode === null || parentNode === void 0 ? void 0 : parentNode.querySelector("input[id$='no-option']");
      if (noOptionNode && noOptionNode instanceof HTMLElement) {
        noOptionNode.click();
      }
    }
  }]);
  return OptionsPage;
}(pages_Common);
/* harmony default export */ const pages_OptionsPage = (OptionsPage);
;// CONCATENATED MODULE: ./classes/pages/PlanPage.ts
function PlanPage_typeof(o) { "@babel/helpers - typeof"; return PlanPage_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, PlanPage_typeof(o); }
function PlanPage_regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ PlanPage_regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == PlanPage_typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator["return"] && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(PlanPage_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, "catch": function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function PlanPage_asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function PlanPage_asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { PlanPage_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { PlanPage_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function PlanPage_classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function PlanPage_defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, PlanPage_toPropertyKey(descriptor.key), descriptor); } }
function PlanPage_createClass(Constructor, protoProps, staticProps) { if (protoProps) PlanPage_defineProperties(Constructor.prototype, protoProps); if (staticProps) PlanPage_defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function PlanPage_toPropertyKey(arg) { var key = PlanPage_toPrimitive(arg, "string"); return PlanPage_typeof(key) === "symbol" ? key : String(key); }
function PlanPage_toPrimitive(input, hint) { if (PlanPage_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (PlanPage_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function PlanPage_inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); Object.defineProperty(subClass, "prototype", { writable: false }); if (superClass) PlanPage_setPrototypeOf(subClass, superClass); }
function PlanPage_setPrototypeOf(o, p) { PlanPage_setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return PlanPage_setPrototypeOf(o, p); }
function PlanPage_createSuper(Derived) { var hasNativeReflectConstruct = PlanPage_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = PlanPage_getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = PlanPage_getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return PlanPage_possibleConstructorReturn(this, result); }; }
function PlanPage_possibleConstructorReturn(self, call) { if (call && (PlanPage_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return PlanPage_assertThisInitialized(self); }
function PlanPage_assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }
function PlanPage_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
function PlanPage_getPrototypeOf(o) { PlanPage_getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return PlanPage_getPrototypeOf(o); }


var PlanPage = /*#__PURE__*/function (_Common) {
  PlanPage_inherits(PlanPage, _Common);
  var _super = PlanPage_createSuper(PlanPage);
  function PlanPage() {
    PlanPage_classCallCheck(this, PlanPage);
    return _super.apply(this, arguments);
  }
  PlanPage_createClass(PlanPage, [{
    key: "waitPlanPageComplete",
    value: function () {
      var _waitPlanPageComplete = PlanPage_asyncToGenerator( /*#__PURE__*/PlanPage_regeneratorRuntime().mark(function _callee() {
        return PlanPage_regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return this.waitFor(function () {
                return window.document.readyState === "complete";
              }, {
                timeout: 60,
                interval: 500
              });
            case 2:
            case "end":
              return _context.stop();
          }
        }, _callee, this);
      }));
      function waitPlanPageComplete() {
        return _waitPlanPageComplete.apply(this, arguments);
      }
      return waitPlanPageComplete;
    }()
  }, {
    key: "fillRequiredFieldByContract",
    value: function () {
      var _fillRequiredFieldByContract = PlanPage_asyncToGenerator( /*#__PURE__*/PlanPage_regeneratorRuntime().mark(function _callee2(contract) {
        var isMnpCarrierAvailable;
        return PlanPage_regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return this.waitForAvailable("#first-mnp-mno");
            case 2:
              isMnpCarrierAvailable = _context2.sent;
              if (!isMnpCarrierAvailable) {
                console.error("The carrier selector isn't available!");
              }
              _context2.next = 6;
              return this.selectFirstElement("#first-mnp-mno");
            case 6:
              _context2.next = 8;
              return this.fillField("#first-mnp-current-msn", "09000121211");
            case 8:
              _context2.next = 10;
              return this.fillField("#first-mnp-reservation-number", contract === "c02" ? "1100111111" : "1300111111");
            case 10:
              _context2.next = 12;
              return this.selectFirstElement("#first-mnp-expiration-date");
            case 12:
            case "end":
              return _context2.stop();
          }
        }, _callee2, this);
      }));
      function fillRequiredFieldByContract(_x) {
        return _fillRequiredFieldByContract.apply(this, arguments);
      }
      return fillRequiredFieldByContract;
    }()
  }, {
    key: "selectContractById",
    value: function () {
      var _selectContractById = PlanPage_asyncToGenerator( /*#__PURE__*/PlanPage_regeneratorRuntime().mark(function _callee3(contract) {
        var config,
          _args3 = arguments;
        return PlanPage_regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
              config = _args3.length > 1 && _args3[1] !== undefined ? _args3[1] : {
                fillRequiredFieldByContract: true
              };
              if (!(contract !== Contract.C01)) {
                _context3.next = 5;
                break;
              }
              this.clickTo("#first-keep-phone-number");
              _context3.next = 5;
              return this.waitTime(0.2);
            case 5:
              _context3.t0 = contract;
              _context3.next = _context3.t0 === Contract.C01 ? 8 : _context3.t0 === Contract.C02 ? 10 : _context3.t0 === Contract.C03 ? 15 : _context3.t0 === Contract.C06 ? 17 : _context3.t0 === Contract.C13 ? 19 : _context3.t0 === Contract.C90 ? 21 : 26;
              break;
            case 8:
              this.clickTo("#first-contract-radio-01-label");
              return _context3.abrupt("break", 26);
            case 10:
              this.clickTo("#first-contract-radio-04-label");
              if (!config.fillRequiredFieldByContract) {
                _context3.next = 14;
                break;
              }
              _context3.next = 14;
              return this.fillRequiredFieldByContract(contract);
            case 14:
              return _context3.abrupt("break", 26);
            case 15:
              this.clickTo("#first-contract-radio-03-label");
              return _context3.abrupt("break", 26);
            case 17:
              this.clickTo("#first-contract-radio-02-label");
              return _context3.abrupt("break", 26);
            case 19:
              this.clickTo("#first-contract-radio-05-label");
              return _context3.abrupt("break", 26);
            case 21:
              this.clickTo("#first-contract-radio-06-label");
              if (!config.fillRequiredFieldByContract) {
                _context3.next = 25;
                break;
              }
              _context3.next = 25;
              return this.fillRequiredFieldByContract(contract);
            case 25:
              return _context3.abrupt("break", 26);
            case 26:
            case "end":
              return _context3.stop();
          }
        }, _callee3, this);
      }));
      function selectContractById(_x2) {
        return _selectContractById.apply(this, arguments);
      }
      return selectContractById;
    }()
  }, {
    key: "selectPlanById",
    value: function selectPlanById(planId) {
      this.clickTo("#first-plan-radio #first-".concat(planId));
    }
  }, {
    key: "selectPaymentCount",
    value: function () {
      var _selectPaymentCount = PlanPage_asyncToGenerator( /*#__PURE__*/PlanPage_regeneratorRuntime().mark(function _callee4(count) {
        var _this$selector;
        return PlanPage_regeneratorRuntime().wrap(function _callee4$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              this.clickTo("input[id^=\"payment-count-radio\"][value=\"".concat(count, "\"]"));
              (_this$selector = this.selector("input[id^=\"payment-count-radio\"][value=\"".concat(count, "\"]"))) === null || _this$selector === void 0 || _this$selector.dispatchEvent(new Event("change"));
            case 2:
            case "end":
              return _context4.stop();
          }
        }, _callee4, this);
      }));
      function selectPaymentCount(_x3) {
        return _selectPaymentCount.apply(this, arguments);
      }
      return selectPaymentCount;
    }()
  }, {
    key: "toggleFamilyDiscount",
    value: function toggleFamilyDiscount(forceChecked) {
      var _this$toInputElement;
      var isChecked = (_this$toInputElement = this.toInputElement("#family-discount")) === null || _this$toInputElement === void 0 ? void 0 : _this$toInputElement.checked;
      if (forceChecked === undefined || forceChecked !== isChecked) {
        this.clickTo("#family-discount-label");
      }
    }
  }, {
    key: "selectBringInDevice",
    value: function () {
      var _selectBringInDevice = PlanPage_asyncToGenerator( /*#__PURE__*/PlanPage_regeneratorRuntime().mark(function _callee5() {
        var device,
          _args5 = arguments;
        return PlanPage_regeneratorRuntime().wrap(function _callee5$(_context5) {
          while (1) switch (_context5.prev = _context5.next) {
            case 0:
              device = _args5.length > 0 && _args5[0] !== undefined ? _args5[0] : DeviceType.Iphone;
              this.clickTo("#first-device-section [name=\"first-device\"][value=\"".concat(DeviceTypeToValueMapping[device], "\"] ~ label"));
            case 2:
            case "end":
              return _context5.stop();
          }
        }, _callee5, this);
      }));
      function selectBringInDevice() {
        return _selectBringInDevice.apply(this, arguments);
      }
      return selectBringInDevice;
    }()
  }, {
    key: "confirmEsim",
    value: function () {
      var _confirmEsim = PlanPage_asyncToGenerator( /*#__PURE__*/PlanPage_regeneratorRuntime().mark(function _callee6() {
        return PlanPage_regeneratorRuntime().wrap(function _callee6$(_context6) {
          while (1) switch (_context6.prev = _context6.next) {
            case 0:
              this.clickTo("#esim-confirmed-check-label");
            case 1:
            case "end":
              return _context6.stop();
          }
        }, _callee6, this);
      }));
      function confirmEsim() {
        return _confirmEsim.apply(this, arguments);
      }
      return confirmEsim;
    }()
  }]);
  return PlanPage;
}(pages_Common);
/* harmony default export */ const pages_PlanPage = (PlanPage);
;// CONCATENATED MODULE: ./classes/pages/UploadPage.ts
function UploadPage_typeof(o) { "@babel/helpers - typeof"; return UploadPage_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, UploadPage_typeof(o); }
function UploadPage_classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function UploadPage_defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, UploadPage_toPropertyKey(descriptor.key), descriptor); } }
function UploadPage_createClass(Constructor, protoProps, staticProps) { if (protoProps) UploadPage_defineProperties(Constructor.prototype, protoProps); if (staticProps) UploadPage_defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function UploadPage_toPropertyKey(arg) { var key = UploadPage_toPrimitive(arg, "string"); return UploadPage_typeof(key) === "symbol" ? key : String(key); }
function UploadPage_toPrimitive(input, hint) { if (UploadPage_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (UploadPage_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function UploadPage_inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); Object.defineProperty(subClass, "prototype", { writable: false }); if (superClass) UploadPage_setPrototypeOf(subClass, superClass); }
function UploadPage_setPrototypeOf(o, p) { UploadPage_setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return UploadPage_setPrototypeOf(o, p); }
function UploadPage_createSuper(Derived) { var hasNativeReflectConstruct = UploadPage_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = UploadPage_getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = UploadPage_getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return UploadPage_possibleConstructorReturn(this, result); }; }
function UploadPage_possibleConstructorReturn(self, call) { if (call && (UploadPage_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return UploadPage_assertThisInitialized(self); }
function UploadPage_assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }
function UploadPage_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
function UploadPage_getPrototypeOf(o) { UploadPage_getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return UploadPage_getPrototypeOf(o); }

var UploadPage = /*#__PURE__*/function (_Common) {
  UploadPage_inherits(UploadPage, _Common);
  var _super = UploadPage_createSuper(UploadPage);
  function UploadPage() {
    UploadPage_classCallCheck(this, UploadPage);
    return _super.apply(this, arguments);
  }
  UploadPage_createClass(UploadPage, [{
    key: "selectContractorAddress",
    value: function selectContractorAddress(isMatchAddress) {
      if (isMatchAddress) {
        this.clickTo("#contractor-address-confirm-radio-01");
        return;
      }
      this.clickTo("#contractor-address-confirm-radio-02");
    }
  }]);
  return UploadPage;
}(pages_Common);
/* harmony default export */ const pages_UploadPage = (UploadPage);
;// CONCATENATED MODULE: ./classes/pages/PaymentPage.ts
function PaymentPage_typeof(o) { "@babel/helpers - typeof"; return PaymentPage_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, PaymentPage_typeof(o); }
function PaymentPage_regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ PaymentPage_regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == PaymentPage_typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator["return"] && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(PaymentPage_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, "catch": function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function PaymentPage_asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function PaymentPage_asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { PaymentPage_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { PaymentPage_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function PaymentPage_classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function PaymentPage_defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, PaymentPage_toPropertyKey(descriptor.key), descriptor); } }
function PaymentPage_createClass(Constructor, protoProps, staticProps) { if (protoProps) PaymentPage_defineProperties(Constructor.prototype, protoProps); if (staticProps) PaymentPage_defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function PaymentPage_toPropertyKey(arg) { var key = PaymentPage_toPrimitive(arg, "string"); return PaymentPage_typeof(key) === "symbol" ? key : String(key); }
function PaymentPage_toPrimitive(input, hint) { if (PaymentPage_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (PaymentPage_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function PaymentPage_inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); Object.defineProperty(subClass, "prototype", { writable: false }); if (superClass) PaymentPage_setPrototypeOf(subClass, superClass); }
function PaymentPage_setPrototypeOf(o, p) { PaymentPage_setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return PaymentPage_setPrototypeOf(o, p); }
function PaymentPage_createSuper(Derived) { var hasNativeReflectConstruct = PaymentPage_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = PaymentPage_getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = PaymentPage_getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return PaymentPage_possibleConstructorReturn(this, result); }; }
function PaymentPage_possibleConstructorReturn(self, call) { if (call && (PaymentPage_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return PaymentPage_assertThisInitialized(self); }
function PaymentPage_assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }
function PaymentPage_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
function PaymentPage_getPrototypeOf(o) { PaymentPage_getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return PaymentPage_getPrototypeOf(o); }

var PaymentPage = /*#__PURE__*/function (_Common) {
  PaymentPage_inherits(PaymentPage, _Common);
  var _super = PaymentPage_createSuper(PaymentPage);
  function PaymentPage() {
    PaymentPage_classCallCheck(this, PaymentPage);
    return _super.apply(this, arguments);
  }
  PaymentPage_createClass(PaymentPage, [{
    key: "checkAvailableCreditCardType",
    value: function () {
      var _checkAvailableCreditCardType = PaymentPage_asyncToGenerator( /*#__PURE__*/PaymentPage_regeneratorRuntime().mark(function _callee() {
        var monthlyPaymentCheckNode, isMonthlyPaymentAvailable;
        return PaymentPage_regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              monthlyPaymentCheckNode = "#monthly-payment-credit-card-number";
              _context.next = 3;
              return this.waitForAvailable(monthlyPaymentCheckNode, {
                timeout: 10
              });
            case 3:
              isMonthlyPaymentAvailable = _context.sent;
              return _context.abrupt("return", isMonthlyPaymentAvailable ? "monthly" : "product");
            case 5:
            case "end":
              return _context.stop();
          }
        }, _callee, this);
      }));
      function checkAvailableCreditCardType() {
        return _checkAvailableCreditCardType.apply(this, arguments);
      }
      return checkAvailableCreditCardType;
    }()
  }, {
    key: "getAvailableCreditCardExpire",
    value: function getAvailableCreditCardExpire(creditCardType) {
      var _this$selector, _this$selector2;
      var expirationYearSelector = "#".concat(creditCardType, "-payment-credit-card-expiration-year");
      var expirationMonthSelector = "#".concat(creditCardType, "-payment-credit-card-expiration-month");
      var expireYear = (_this$selector = this.selector(expirationYearSelector)) === null || _this$selector === void 0 || (_this$selector = _this$selector.querySelector("option:nth-child(3)")) === null || _this$selector === void 0 ? void 0 : _this$selector.getAttribute("value");
      var expireMonth = (_this$selector2 = this.selector(expirationMonthSelector)) === null || _this$selector2 === void 0 || (_this$selector2 = _this$selector2.querySelector("option:nth-child(3)")) === null || _this$selector2 === void 0 ? void 0 : _this$selector2.getAttribute("value");
      return {
        expireYear: expireYear,
        expireMonth: expireMonth
      };
    }
  }, {
    key: "fillCreditCardInformation",
    value: function () {
      var _fillCreditCardInformation = PaymentPage_asyncToGenerator( /*#__PURE__*/PaymentPage_regeneratorRuntime().mark(function _callee2() {
        var creditCardInformation,
          creditCardNumber,
          expireYear,
          expireMonth,
          securityCode,
          creditCardType,
          _this$getAvailableCre,
          expirationYearAvailableValue,
          expirationMonthAvailableValue,
          _args2 = arguments;
        return PaymentPage_regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              creditCardInformation = _args2.length > 0 && _args2[0] !== undefined ? _args2[0] : {
                creditCardNumber: "4111111111111111",
                expireYear: "40",
                expireMonth: "07",
                securityCode: "432"
              };
              creditCardNumber = creditCardInformation.creditCardNumber, expireYear = creditCardInformation.expireYear, expireMonth = creditCardInformation.expireMonth, securityCode = creditCardInformation.securityCode;
              _context2.next = 4;
              return this.checkAvailableCreditCardType();
            case 4:
              creditCardType = _context2.sent;
              _this$getAvailableCre = this.getAvailableCreditCardExpire(creditCardType), expirationYearAvailableValue = _this$getAvailableCre.expireYear, expirationMonthAvailableValue = _this$getAvailableCre.expireMonth;
              _context2.next = 8;
              return this.fillField("#".concat(creditCardType, "-payment-credit-card-number"), creditCardNumber);
            case 8:
              _context2.next = 10;
              return this.select("#".concat(creditCardType, "-payment-credit-card-expiration-year"), creditCardInformation.expireMonth ? expirationYearAvailableValue : expireYear);
            case 10:
              _context2.next = 12;
              return this.waitTime(0.1);
            case 12:
              _context2.next = 14;
              return this.select("#".concat(creditCardType, "-payment-credit-card-expiration-month"), (creditCardInformation.expireMonth ? expirationMonthAvailableValue : expireMonth).padStart(2, "0"));
            case 14:
              _context2.next = 16;
              return this.fillField("#".concat(creditCardType, "-payment-credit-card-security-code"), securityCode);
            case 16:
            case "end":
              return _context2.stop();
          }
        }, _callee2, this);
      }));
      function fillCreditCardInformation() {
        return _fillCreditCardInformation.apply(this, arguments);
      }
      return fillCreditCardInformation;
    }()
  }]);
  return PaymentPage;
}(pages_Common);
/* harmony default export */ const pages_PaymentPage = (PaymentPage);
;// CONCATENATED MODULE: ./classes/pages/AgreementPage.ts
function AgreementPage_typeof(o) { "@babel/helpers - typeof"; return AgreementPage_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, AgreementPage_typeof(o); }
function AgreementPage_regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ AgreementPage_regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == AgreementPage_typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator["return"] && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(AgreementPage_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, "catch": function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function AgreementPage_asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function AgreementPage_asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { AgreementPage_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { AgreementPage_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function AgreementPage_classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function AgreementPage_defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, AgreementPage_toPropertyKey(descriptor.key), descriptor); } }
function AgreementPage_createClass(Constructor, protoProps, staticProps) { if (protoProps) AgreementPage_defineProperties(Constructor.prototype, protoProps); if (staticProps) AgreementPage_defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function AgreementPage_toPropertyKey(arg) { var key = AgreementPage_toPrimitive(arg, "string"); return AgreementPage_typeof(key) === "symbol" ? key : String(key); }
function AgreementPage_toPrimitive(input, hint) { if (AgreementPage_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (AgreementPage_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function AgreementPage_inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); Object.defineProperty(subClass, "prototype", { writable: false }); if (superClass) AgreementPage_setPrototypeOf(subClass, superClass); }
function AgreementPage_setPrototypeOf(o, p) { AgreementPage_setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return AgreementPage_setPrototypeOf(o, p); }
function AgreementPage_createSuper(Derived) { var hasNativeReflectConstruct = AgreementPage_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = AgreementPage_getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = AgreementPage_getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return AgreementPage_possibleConstructorReturn(this, result); }; }
function AgreementPage_possibleConstructorReturn(self, call) { if (call && (AgreementPage_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return AgreementPage_assertThisInitialized(self); }
function AgreementPage_assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }
function AgreementPage_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
function AgreementPage_getPrototypeOf(o) { AgreementPage_getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return AgreementPage_getPrototypeOf(o); }


var AgreementPage = /*#__PURE__*/function (_Common) {
  AgreementPage_inherits(AgreementPage, _Common);
  var _super = AgreementPage_createSuper(AgreementPage);
  function AgreementPage() {
    AgreementPage_classCallCheck(this, AgreementPage);
    return _super.apply(this, arguments);
  }
  AgreementPage_createClass(AgreementPage, [{
    key: "agreeAgreement",
    value: function () {
      var _agreeAgreement = AgreementPage_asyncToGenerator( /*#__PURE__*/AgreementPage_regeneratorRuntime().mark(function _callee() {
        var clickToNextPage,
          serviceNoteButton,
          isTelecomPrivacyAvailable,
          isFilteringAgreementAvailable,
          _args = arguments;
        return AgreementPage_regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              clickToNextPage = _args.length > 0 && _args[0] !== undefined ? _args[0] : false;
              serviceNoteButton = this.findElementByText("重要説明事項を確認する");
              if (serviceNoteButton && serviceNoteButton instanceof HTMLElement) {
                serviceNoteButton.click();
              } else {
                console.error("Cannot find the service notes agreement ");
              }
              _context.next = 5;
              return this.waitForClickable("label[for='telecom-privacy-agreement-checkbox']");
            case 5:
              isTelecomPrivacyAvailable = _context.sent;
              if (isTelecomPrivacyAvailable) {
                this.clickTo("label[for='telecom-privacy-agreement-checkbox']");
              }
              if (!this.checkElementExist("#first-show-filtering-agreement")) {
                _context.next = 13;
                break;
              }
              this.clickTo("#first-show-filtering-agreement");
              _context.next = 11;
              return this.waitForClickable("label[for='first-filtering-agreement-checkbox']");
            case 11:
              isFilteringAgreementAvailable = _context.sent;
              if (isFilteringAgreementAvailable) {
                this.clickTo("label[for='first-filtering-agreement-checkbox']");
              }
            case 13:
              this.clickTo("label[for='agreement-kappu-checkbox']");
              this.clickTo("label[for='agreement-business-law-checkbox']");
              if (!clickToNextPage) {
                _context.next = 18;
                break;
              }
              _context.next = 18;
              return this.nextPage(PageTitle.AGREEMENT);
            case 18:
            case "end":
              return _context.stop();
          }
        }, _callee, this);
      }));
      function agreeAgreement() {
        return _agreeAgreement.apply(this, arguments);
      }
      return agreeAgreement;
    }()
  }]);
  return AgreementPage;
}(pages_Common);
/* harmony default export */ const pages_AgreementPage = (AgreementPage);
;// CONCATENATED MODULE: ./classes/pages/CompanySalePage.ts
function CompanySalePage_typeof(o) { "@babel/helpers - typeof"; return CompanySalePage_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, CompanySalePage_typeof(o); }
function CompanySalePage_regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ CompanySalePage_regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == CompanySalePage_typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator["return"] && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(CompanySalePage_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, "catch": function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function CompanySalePage_asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function CompanySalePage_asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { CompanySalePage_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { CompanySalePage_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function CompanySalePage_classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function CompanySalePage_defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, CompanySalePage_toPropertyKey(descriptor.key), descriptor); } }
function CompanySalePage_createClass(Constructor, protoProps, staticProps) { if (protoProps) CompanySalePage_defineProperties(Constructor.prototype, protoProps); if (staticProps) CompanySalePage_defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function CompanySalePage_toPropertyKey(arg) { var key = CompanySalePage_toPrimitive(arg, "string"); return CompanySalePage_typeof(key) === "symbol" ? key : String(key); }
function CompanySalePage_toPrimitive(input, hint) { if (CompanySalePage_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (CompanySalePage_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function CompanySalePage_inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); Object.defineProperty(subClass, "prototype", { writable: false }); if (superClass) CompanySalePage_setPrototypeOf(subClass, superClass); }
function CompanySalePage_setPrototypeOf(o, p) { CompanySalePage_setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return CompanySalePage_setPrototypeOf(o, p); }
function CompanySalePage_createSuper(Derived) { var hasNativeReflectConstruct = CompanySalePage_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = CompanySalePage_getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = CompanySalePage_getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return CompanySalePage_possibleConstructorReturn(this, result); }; }
function CompanySalePage_possibleConstructorReturn(self, call) { if (call && (CompanySalePage_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return CompanySalePage_assertThisInitialized(self); }
function CompanySalePage_assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }
function CompanySalePage_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
function CompanySalePage_getPrototypeOf(o) { CompanySalePage_getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return CompanySalePage_getPrototypeOf(o); }

var CompanySalePage = /*#__PURE__*/function (_Common) {
  CompanySalePage_inherits(CompanySalePage, _Common);
  var _super = CompanySalePage_createSuper(CompanySalePage);
  function CompanySalePage() {
    CompanySalePage_classCallCheck(this, CompanySalePage);
    return _super.apply(this, arguments);
  }
  CompanySalePage_createClass(CompanySalePage, [{
    key: "goToSyainPlanPage",
    value: function () {
      var _goToSyainPlanPage = CompanySalePage_asyncToGenerator( /*#__PURE__*/CompanySalePage_regeneratorRuntime().mark(function _callee() {
        var _this = this;
        var allAnswersNodes;
        return CompanySalePage_regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              allAnswersNodes = this.selectorAll("#area_input table tbody tr td:nth-child(2) .formradio-inline-item:first-child input[name*='answer_']");
              allAnswersNodes.forEach(function (node) {
                return _this.clickTo(node);
              });
              this.clickTo('#button_confirm');
              _context.next = 5;
              return this.waitForAvailable('#button_submit');
            case 5:
              this.clickTo('#button_submit');
            case 6:
            case "end":
              return _context.stop();
          }
        }, _callee, this);
      }));
      function goToSyainPlanPage() {
        return _goToSyainPlanPage.apply(this, arguments);
      }
      return goToSyainPlanPage;
    }()
  }]);
  return CompanySalePage;
}(pages_Common);
/* harmony default export */ const pages_CompanySalePage = (CompanySalePage);
;// CONCATENATED MODULE: ../node_modules/ts-mixer/dist/esm/index.js
/**
 * Utility function that works like `Object.apply`, but copies getters and setters properly as well.  Additionally gives
 * the option to exclude properties by name.
 */
const copyProps = (dest, src, exclude = []) => {
    const props = Object.getOwnPropertyDescriptors(src);
    for (let prop of exclude)
        delete props[prop];
    Object.defineProperties(dest, props);
};
/**
 * Returns the full chain of prototypes up until Object.prototype given a starting object.  The order of prototypes will
 * be closest to farthest in the chain.
 */
const protoChain = (obj, currentChain = [obj]) => {
    const proto = Object.getPrototypeOf(obj);
    if (proto === null)
        return currentChain;
    return protoChain(proto, [...currentChain, proto]);
};
/**
 * Identifies the nearest ancestor common to all the given objects in their prototype chains.  For most unrelated
 * objects, this function should return Object.prototype.
 */
const nearestCommonProto = (...objs) => {
    if (objs.length === 0)
        return undefined;
    let commonProto = undefined;
    const protoChains = objs.map(obj => protoChain(obj));
    while (protoChains.every(protoChain => protoChain.length > 0)) {
        const protos = protoChains.map(protoChain => protoChain.pop());
        const potentialCommonProto = protos[0];
        if (protos.every(proto => proto === potentialCommonProto))
            commonProto = potentialCommonProto;
        else
            break;
    }
    return commonProto;
};
/**
 * Creates a new prototype object that is a mixture of the given prototypes.  The mixing is achieved by first
 * identifying the nearest common ancestor and using it as the prototype for a new object.  Then all properties/methods
 * downstream of this prototype (ONLY downstream) are copied into the new object.
 *
 * The resulting prototype is more performant than softMixProtos(...), as well as ES5 compatible.  However, it's not as
 * flexible as updates to the source prototypes aren't captured by the mixed result.  See softMixProtos for why you may
 * want to use that instead.
 */
const hardMixProtos = (ingredients, constructor, exclude = []) => {
    var _a;
    const base = (_a = nearestCommonProto(...ingredients)) !== null && _a !== void 0 ? _a : Object.prototype;
    const mixedProto = Object.create(base);
    // Keeps track of prototypes we've already visited to avoid copying the same properties multiple times.  We init the
    // list with the proto chain below the nearest common ancestor because we don't want any of those methods mixed in
    // when they will already be accessible via prototype access.
    const visitedProtos = protoChain(base);
    for (let prototype of ingredients) {
        let protos = protoChain(prototype);
        // Apply the prototype chain in reverse order so that old methods don't override newer ones.
        for (let i = protos.length - 1; i >= 0; i--) {
            let newProto = protos[i];
            if (visitedProtos.indexOf(newProto) === -1) {
                copyProps(mixedProto, newProto, ['constructor', ...exclude]);
                visitedProtos.push(newProto);
            }
        }
    }
    mixedProto.constructor = constructor;
    return mixedProto;
};
const unique = (arr) => arr.filter((e, i) => arr.indexOf(e) == i);

/**
 * Finds the ingredient with the given prop, searching in reverse order and breadth-first if searching ingredient
 * prototypes is required.
 */
const getIngredientWithProp = (prop, ingredients) => {
    const protoChains = ingredients.map(ingredient => protoChain(ingredient));
    // since we search breadth-first, we need to keep track of our depth in the prototype chains
    let protoDepth = 0;
    // not all prototype chains are the same depth, so this remains true as long as at least one of the ingredients'
    // prototype chains has an object at this depth
    let protosAreLeftToSearch = true;
    while (protosAreLeftToSearch) {
        // with the start of each horizontal slice, we assume this is the one that's deeper than any of the proto chains
        protosAreLeftToSearch = false;
        // scan through the ingredients right to left
        for (let i = ingredients.length - 1; i >= 0; i--) {
            const searchTarget = protoChains[i][protoDepth];
            if (searchTarget !== undefined && searchTarget !== null) {
                // if we find something, this is proof that this horizontal slice potentially more objects to search
                protosAreLeftToSearch = true;
                // eureka, we found it
                if (Object.getOwnPropertyDescriptor(searchTarget, prop) != undefined) {
                    return protoChains[i][0];
                }
            }
        }
        protoDepth++;
    }
    return undefined;
};
/**
 * "Mixes" ingredients by wrapping them in a Proxy.  The optional prototype argument allows the mixed object to sit
 * downstream of an existing prototype chain.  Note that "properties" cannot be added, deleted, or modified.
 */
const proxyMix = (ingredients, prototype = Object.prototype) => new Proxy({}, {
    getPrototypeOf() {
        return prototype;
    },
    setPrototypeOf() {
        throw Error('Cannot set prototype of Proxies created by ts-mixer');
    },
    getOwnPropertyDescriptor(_, prop) {
        return Object.getOwnPropertyDescriptor(getIngredientWithProp(prop, ingredients) || {}, prop);
    },
    defineProperty() {
        throw new Error('Cannot define new properties on Proxies created by ts-mixer');
    },
    has(_, prop) {
        return getIngredientWithProp(prop, ingredients) !== undefined || prototype[prop] !== undefined;
    },
    get(_, prop) {
        return (getIngredientWithProp(prop, ingredients) || prototype)[prop];
    },
    set(_, prop, val) {
        const ingredientWithProp = getIngredientWithProp(prop, ingredients);
        if (ingredientWithProp === undefined)
            throw new Error('Cannot set new properties on Proxies created by ts-mixer');
        ingredientWithProp[prop] = val;
        return true;
    },
    deleteProperty() {
        throw new Error('Cannot delete properties on Proxies created by ts-mixer');
    },
    ownKeys() {
        return ingredients
            .map(Object.getOwnPropertyNames)
            .reduce((prev, curr) => curr.concat(prev.filter(key => curr.indexOf(key) < 0)));
    },
});
/**
 * Creates a new proxy-prototype object that is a "soft" mixture of the given prototypes.  The mixing is achieved by
 * proxying all property access to the ingredients.  This is not ES5 compatible and less performant.  However, any
 * changes made to the source prototypes will be reflected in the proxy-prototype, which may be desirable.
 */
const softMixProtos = (ingredients, constructor) => proxyMix([...ingredients, { constructor }]);

const settings = {
    initFunction: null,
    staticsStrategy: 'copy',
    prototypeStrategy: 'copy',
    decoratorInheritance: 'deep',
};

// Keeps track of constituent classes for every mixin class created by ts-mixer.
const mixins = new Map();
const getMixinsForClass = (clazz) => mixins.get(clazz);
const registerMixins = (mixedClass, constituents) => mixins.set(mixedClass, constituents);
const hasMixin = (instance, mixin) => {
    if (instance instanceof mixin)
        return true;
    const constructor = instance.constructor;
    const visited = new Set();
    let frontier = new Set();
    frontier.add(constructor);
    while (frontier.size > 0) {
        // check if the frontier has the mixin we're looking for.  if not, we can say we visited every item in the frontier
        if (frontier.has(mixin))
            return true;
        frontier.forEach(item => visited.add(item));
        // build a new frontier based on the associated mixin classes and prototype chains of each frontier item
        const newFrontier = new Set();
        frontier.forEach(item => {
            var _a;
            const itemConstituents = (_a = mixins.get(item)) !== null && _a !== void 0 ? _a : protoChain(item.prototype).map(proto => proto.constructor).filter(item => item !== null);
            if (itemConstituents)
                itemConstituents.forEach(constituent => {
                    if (!visited.has(constituent) && !frontier.has(constituent))
                        newFrontier.add(constituent);
                });
        });
        // we have a new frontier, now search again
        frontier = newFrontier;
    }
    // if we get here, we couldn't find the mixin anywhere in the prototype chain or associated mixin classes
    return false;
};

const mergeObjectsOfDecorators = (o1, o2) => {
    var _a, _b;
    const allKeys = unique([...Object.getOwnPropertyNames(o1), ...Object.getOwnPropertyNames(o2)]);
    const mergedObject = {};
    for (let key of allKeys)
        mergedObject[key] = unique([...((_a = o1 === null || o1 === void 0 ? void 0 : o1[key]) !== null && _a !== void 0 ? _a : []), ...((_b = o2 === null || o2 === void 0 ? void 0 : o2[key]) !== null && _b !== void 0 ? _b : [])]);
    return mergedObject;
};
const mergePropertyAndMethodDecorators = (d1, d2) => {
    var _a, _b, _c, _d;
    return ({
        property: mergeObjectsOfDecorators((_a = d1 === null || d1 === void 0 ? void 0 : d1.property) !== null && _a !== void 0 ? _a : {}, (_b = d2 === null || d2 === void 0 ? void 0 : d2.property) !== null && _b !== void 0 ? _b : {}),
        method: mergeObjectsOfDecorators((_c = d1 === null || d1 === void 0 ? void 0 : d1.method) !== null && _c !== void 0 ? _c : {}, (_d = d2 === null || d2 === void 0 ? void 0 : d2.method) !== null && _d !== void 0 ? _d : {}),
    });
};
const mergeDecorators = (d1, d2) => {
    var _a, _b, _c, _d, _e, _f;
    return ({
        class: unique([...(_a = d1 === null || d1 === void 0 ? void 0 : d1.class) !== null && _a !== void 0 ? _a : [], ...(_b = d2 === null || d2 === void 0 ? void 0 : d2.class) !== null && _b !== void 0 ? _b : []]),
        static: mergePropertyAndMethodDecorators((_c = d1 === null || d1 === void 0 ? void 0 : d1.static) !== null && _c !== void 0 ? _c : {}, (_d = d2 === null || d2 === void 0 ? void 0 : d2.static) !== null && _d !== void 0 ? _d : {}),
        instance: mergePropertyAndMethodDecorators((_e = d1 === null || d1 === void 0 ? void 0 : d1.instance) !== null && _e !== void 0 ? _e : {}, (_f = d2 === null || d2 === void 0 ? void 0 : d2.instance) !== null && _f !== void 0 ? _f : {}),
    });
};
const decorators = new Map();
const findAllConstituentClasses = (...classes) => {
    var _a;
    const allClasses = new Set();
    const frontier = new Set([...classes]);
    while (frontier.size > 0) {
        for (let clazz of frontier) {
            const protoChainClasses = protoChain(clazz.prototype).map(proto => proto.constructor);
            const mixinClasses = (_a = getMixinsForClass(clazz)) !== null && _a !== void 0 ? _a : [];
            const potentiallyNewClasses = [...protoChainClasses, ...mixinClasses];
            const newClasses = potentiallyNewClasses.filter(c => !allClasses.has(c));
            for (let newClass of newClasses)
                frontier.add(newClass);
            allClasses.add(clazz);
            frontier.delete(clazz);
        }
    }
    return [...allClasses];
};
const deepDecoratorSearch = (...classes) => {
    const decoratorsForClassChain = findAllConstituentClasses(...classes)
        .map(clazz => decorators.get(clazz))
        .filter(decorators => !!decorators);
    if (decoratorsForClassChain.length == 0)
        return {};
    if (decoratorsForClassChain.length == 1)
        return decoratorsForClassChain[0];
    return decoratorsForClassChain.reduce((d1, d2) => mergeDecorators(d1, d2));
};
const directDecoratorSearch = (...classes) => {
    const classDecorators = classes.map(clazz => getDecoratorsForClass(clazz));
    if (classDecorators.length === 0)
        return {};
    if (classDecorators.length === 1)
        return classDecorators[0];
    return classDecorators.reduce((d1, d2) => mergeDecorators(d1, d2));
};
const getDecoratorsForClass = (clazz) => {
    let decoratorsForClass = decorators.get(clazz);
    if (!decoratorsForClass) {
        decoratorsForClass = {};
        decorators.set(clazz, decoratorsForClass);
    }
    return decoratorsForClass;
};
const decorateClass = (decorator) => ((clazz) => {
    const decoratorsForClass = getDecoratorsForClass(clazz);
    let classDecorators = decoratorsForClass.class;
    if (!classDecorators) {
        classDecorators = [];
        decoratorsForClass.class = classDecorators;
    }
    classDecorators.push(decorator);
    return decorator(clazz);
});
const decorateMember = (decorator) => ((object, key, ...otherArgs) => {
    var _a, _b, _c;
    const decoratorTargetType = typeof object === 'function' ? 'static' : 'instance';
    const decoratorType = typeof object[key] === 'function' ? 'method' : 'property';
    const clazz = decoratorTargetType === 'static' ? object : object.constructor;
    const decoratorsForClass = getDecoratorsForClass(clazz);
    const decoratorsForTargetType = (_a = decoratorsForClass === null || decoratorsForClass === void 0 ? void 0 : decoratorsForClass[decoratorTargetType]) !== null && _a !== void 0 ? _a : {};
    decoratorsForClass[decoratorTargetType] = decoratorsForTargetType;
    let decoratorsForType = (_b = decoratorsForTargetType === null || decoratorsForTargetType === void 0 ? void 0 : decoratorsForTargetType[decoratorType]) !== null && _b !== void 0 ? _b : {};
    decoratorsForTargetType[decoratorType] = decoratorsForType;
    let decoratorsForKey = (_c = decoratorsForType === null || decoratorsForType === void 0 ? void 0 : decoratorsForType[key]) !== null && _c !== void 0 ? _c : [];
    decoratorsForType[key] = decoratorsForKey;
    // @ts-ignore: array is type `A[] | B[]` and item is type `A | B`, so technically a type error, but it's fine
    decoratorsForKey.push(decorator);
    // @ts-ignore
    return decorator(object, key, ...otherArgs);
});
const decorate = (decorator) => ((...args) => {
    if (args.length === 1)
        return decorateClass(decorator)(args[0]);
    return decorateMember(decorator)(...args);
});

function Mixin(...constructors) {
    var _a, _b, _c;
    const prototypes = constructors.map(constructor => constructor.prototype);
    // Here we gather up the init functions of the ingredient prototypes, combine them into one init function, and
    // attach it to the mixed class prototype.  The reason we do this is because we want the init functions to mix
    // similarly to constructors -- not methods, which simply override each other.
    const initFunctionName = settings.initFunction;
    if (initFunctionName !== null) {
        const initFunctions = prototypes
            .map(proto => proto[initFunctionName])
            .filter(func => typeof func === 'function');
        const combinedInitFunction = function (...args) {
            for (let initFunction of initFunctions)
                initFunction.apply(this, args);
        };
        const extraProto = { [initFunctionName]: combinedInitFunction };
        prototypes.push(extraProto);
    }
    function MixedClass(...args) {
        for (const constructor of constructors)
            // @ts-ignore: potentially abstract class
            copyProps(this, new constructor(...args));
        if (initFunctionName !== null && typeof this[initFunctionName] === 'function')
            this[initFunctionName].apply(this, args);
    }
    MixedClass.prototype = settings.prototypeStrategy === 'copy'
        ? hardMixProtos(prototypes, MixedClass)
        : softMixProtos(prototypes, MixedClass);
    Object.setPrototypeOf(MixedClass, settings.staticsStrategy === 'copy'
        ? hardMixProtos(constructors, null, ['prototype'])
        : proxyMix(constructors, Function.prototype));
    let DecoratedMixedClass = MixedClass;
    if (settings.decoratorInheritance !== 'none') {
        const classDecorators = settings.decoratorInheritance === 'deep'
            ? deepDecoratorSearch(...constructors)
            : directDecoratorSearch(...constructors);
        for (let decorator of (_a = classDecorators === null || classDecorators === void 0 ? void 0 : classDecorators.class) !== null && _a !== void 0 ? _a : []) {
            const result = decorator(DecoratedMixedClass);
            if (result) {
                DecoratedMixedClass = result;
            }
        }
        applyPropAndMethodDecorators((_b = classDecorators === null || classDecorators === void 0 ? void 0 : classDecorators.static) !== null && _b !== void 0 ? _b : {}, DecoratedMixedClass);
        applyPropAndMethodDecorators((_c = classDecorators === null || classDecorators === void 0 ? void 0 : classDecorators.instance) !== null && _c !== void 0 ? _c : {}, DecoratedMixedClass.prototype);
    }
    registerMixins(DecoratedMixedClass, constructors);
    return DecoratedMixedClass;
}
const applyPropAndMethodDecorators = (propAndMethodDecorators, target) => {
    const propDecorators = propAndMethodDecorators.property;
    const methodDecorators = propAndMethodDecorators.method;
    if (propDecorators)
        for (let key in propDecorators)
            for (let decorator of propDecorators[key])
                decorator(target, key);
    if (methodDecorators)
        for (let key in methodDecorators)
            for (let decorator of methodDecorators[key])
                decorator(target, key, Object.getOwnPropertyDescriptor(target, key));
};
/**
 * A decorator version of the `Mixin` function.  You'll want to use this instead of `Mixin` for mixing generic classes.
 */
const mix = (...ingredients) => decoratedClass => {
    // @ts-ignore
    const mixedClass = Mixin(...ingredients.concat([decoratedClass]));
    Object.defineProperty(mixedClass, 'name', {
        value: decoratedClass.name,
        writable: false,
    });
    return mixedClass;
};



;// CONCATENATED MODULE: ./classes/interactive/Interactive.ts








/* harmony default export */ const Interactive = (Mixin(pages_PlanPage, pages_OptionsPage, pages_UploadPage, pages_InputPage, pages_PaymentPage, pages_AgreementPage, pages_CompanySalePage));
;// CONCATENATED MODULE: ./chrome_scripts/contents/main_scripts.ts


console.log("Start Interactive. Running in the MAIN world...");
window.I = new Interactive();
window.Mock = mocks_MockApi;
/******/ })()
;